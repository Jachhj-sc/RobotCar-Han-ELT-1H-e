/*
 * blinker.h
 *
 * Created: 26-1-2021 13:14:06
 *  Author: willi
 */ 


#ifndef BLINKER_H_
#define BLINKER_H_

#define Left 'l'
#define Right 'r'
#define VOID ' '
void blinkerController(char LR);
void initBlinker();

#endif /* BLINKER_H_ */